﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ts1Form
{
    internal struct Complex
    {
        public double im;
        public double re;


        /// <summary> Метод сложения с другим комплексным числом </summary>
        /// <param name="x">Комплексное число для сложения</param>
        /// <returns></returns>
        public Complex Plus(Complex x)
        {
            Complex y;
            y.im = im + x.im;
            y.re = re + x.re;
            return y;
        }
        /// <summary> Метод разности с другим комплексным числом </summary>
        /// <param name="x">Комплексное число для разности</param>
        /// <returns></returns>
        public Complex Minus(Complex x)
        {
            Complex y;
            y.im = im - x.im;
            y.re = re - x.re;
            return y;
        }
        /// <summary> Метод произведения с другим комплексным числом </summary>
        /// <param name="x">Комплексное число для произведения</param>
        /// <returns></returns>
        public Complex Multi(Complex x)
        {
            Complex y;
            y.im = re * x.im + im * x.re;
            y.re = re * x.re - im * x.im;
            return y;
        }
        /// <summary>
        /// Метод вычисления модуля числа
        /// </summary>
        /// <returns>Выводит модуль числа в виде double</returns>
        public double Module()
        {
            Complex y;
            y.im = im * im;
            y.re = re * re;
            double abs = Math.Sqrt(y.re + y.im);
            return abs;
        }
        /// <summary> Метод представления комплексного числа в удобной форме</summary>
        public override string ToString()
        {
            if (im < 0)
            {
                return re + "" + im + "i";
            }
            else
            {
                return re + "+" + im + "i";
            }
        }


        // Метод, который перегружает оператор +
        public static Complex operator +(Complex x, Complex y)
        {
            return x.Plus(y);
        }

        // Метод, который перегружает оператор -
        public static Complex operator -(Complex x, Complex y)
        {
            return x.Minus(y);
        }

        // Метод, который перегружает оператор *
        public static Complex operator *(Complex x, Complex y)
        {
            return x.Multi(y);
        }

        // Метод, который перегружает оператор ==
        public static bool operator ==(Complex x, Complex y)
        {

            if ((x.re != y.re) || (x.im != y.im))
            {
                return false;
            }

            return true;
        }

        // Метод, который перегружает оператор !=
        public static bool operator !=(Complex x, Complex y)
        {
            if ((x.re == y.re) && (x.im == y.im))
            {
                return false;
            }

            return true;
        }
    }


    public partial class Form1 : Form
    {
        Complex complex1;
        Complex complex2;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Complex result;
           
            complex1.re = Convert.ToDouble(tbRe1.Text);
            complex1.im = Convert.ToDouble(tbIm1.Text);
           
                complex2.re = Convert.ToDouble(tbRe2.Text);
                complex2.im = Convert.ToDouble(tbIm2.Text);
          
            
            if(cbOp.SelectedItem.ToString() == "+")
            {
                result = complex1 + complex2;
                MessageBox.Show(result.ToString());
            }
            if (cbOp.SelectedItem.ToString() == "-")
            {
                result = complex1 - complex2;
                MessageBox.Show(result.ToString());
            }
            if (cbOp.SelectedItem.ToString() == "*")
            {
                result = complex1 * complex2;
                MessageBox.Show(result.ToString());
            }
            if (cbOp.SelectedItem.ToString() == "==")
            {
                if (complex1 == complex2)
                {
                    MessageBox.Show("true");
                }
                else
                {
                    MessageBox.Show("false");
                }
            }
            if (cbOp.SelectedItem.ToString() == "!=")
            {
                if (complex1 != complex2)
                {
                    MessageBox.Show("true");
                }
                else
                {
                    MessageBox.Show("false");
                }
            }

            if (cbOp.SelectedItem.ToString() == "abs")
            {
                MessageBox.Show(Convert.ToString(complex1.Module()));
            }


        }
    }
}
