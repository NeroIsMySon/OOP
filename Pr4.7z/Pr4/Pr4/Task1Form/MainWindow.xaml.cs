﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task1Form
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        internal struct Complex
        {
            public double im;
            public double re;


            /// <summary> Метод сложения с другим комплексным числом </summary>
            /// <param name="x">Комплексное число для сложения</param>
            /// <returns></returns>
            public Complex Plus(Complex x)
            {
                Complex y;
                y.im = im + x.im;
                y.re = re + x.re;
                return y;
            }
            /// <summary> Метод разности с другим комплексным числом </summary>
            /// <param name="x">Комплексное число для разности</param>
            /// <returns></returns>
            public Complex Minus(Complex x)
            {
                Complex y;
                y.im = im - x.im;
                y.re = re - x.re;
                return y;
            }
            /// <summary> Метод произведения с другим комплексным числом </summary>
            /// <param name="x">Комплексное число для произведения</param>
            /// <returns></returns>
            public Complex Multi(Complex x)
            {
                Complex y;
                y.im = re * x.im + im * x.re;
                y.re = re * x.re - im * x.im;
                return y;
            }
            /// <summary>
            /// Метод вычисления модуля числа
            /// </summary>
            /// <returns>Выводит модуль числа в виде double</returns>
            public double Module()
            {
                Complex y;
                y.im = im * im;
                y.re = re * re;
                double abs = Math.Sqrt(y.re + y.im);
                return abs;
            }
            /// <summary> Метод представления комплексного числа в удобной форме</summary>
            public override string ToString()
            {
                if (im < 0)
                {
                    return re + "" + im + "i";
                }
                else
                {
                    return re + "+" + im + "i";
                }
            }


            // Метод, который перегружает оператор +
            public static Complex operator +(Complex x, Complex y)
            {
                return x.Plus(y);
            }

            // Метод, который перегружает оператор -
            public static Complex operator -(Complex x, Complex y)
            {
                return x.Minus(y);
            }

            // Метод, который перегружает оператор *
            public static Complex operator *(Complex x, Complex y)
            {
                return x.Multi(y);
            }

            // Метод, который перегружает оператор ==
            public static bool operator ==(Complex x, Complex y)
            {

                if ((x.re != y.re) || (x.im != y.im))
                {
                    return false;
                }

                return true;
            }

            // Метод, который перегружает оператор !=
            public static bool operator !=(Complex x, Complex y)
            {
                if ((x.re == y.re) && (x.im == y.im))
                {
                    return false;
                }

                return true;
            }
        }


public MainWindow()
        {
            InitializeComponent();

            Complex complex1;
            complex1.re = Convert.ToDouble(Re1.Text);
            complex1.im = Convert.ToDouble(Im1.Text);

            Complex complex2;
            complex2.re = 2;
            complex2.im = 2;
            lbRes.Content = complex2 + complex1;


        }

        private void btCalc_Click(object sender, RoutedEventArgs e)
        {
           
        }
    }


      
}
