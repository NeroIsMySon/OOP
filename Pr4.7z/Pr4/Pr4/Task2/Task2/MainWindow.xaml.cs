﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace Task2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        void AddToListBox(Array array, ListBox x)
        {
            foreach (object obj in array)
            {
                x.Items.Add(obj);
            }
        }

        /// <summary>
        /// Enumeration of girder material types
        /// </summary>
        public enum Material
        {
            StainlessSteel = 4,
            Aluminium = 3,
            ReinforcedConcrete = 2,
            Composite = 1,
            Titanium = 5
        }
        /// <summary>
        /// Enumeration of girder cross-sections
        /// </summary>
        public enum CrossSection
        {
            IBeam = 4,
            Box = 3,
            ZShaped = 2,
            CShaped = 1
        }
        /// <summary>
        /// Enumeration of test results
        /// </summary>
        public enum TestResult
        {
            Pass,
            Fail
        }

        /// Structure containing test results
        /// </summary>
        public struct TestCaseResult
        {
            /// <summary>
            /// Test result (enumeration type)
            /// </summary>
            public TestResult Result;
            /// <summary>
            /// Description of reason for failure
            /// </summary>
            public string ReasonForFailure;
        }

        public MainWindow()
        {
            InitializeComponent();
            Array arrMaterials = typeof(Material).GetEnumValues();
            Array arrCrossSect = typeof(CrossSection).GetEnumValues();
            Array arrTestResult = typeof(TestResult).GetEnumValues();
           

            AddToListBox(arrMaterials, materials);
            AddToListBox(arrCrossSect, crosssections);
            AddToListBox(arrTestResult, testresults);     

        }      

       

        private void Selection_Changed(object sender, SelectionChangedEventArgs e)
        {
            StringBuilder selectionStringBuilder = new StringBuilder();
            if (materials.SelectedItem != null)
            {
                Material selectedMaterial = (Material)materials.SelectedItem;
                switch (selectedMaterial)
                {
                    case Material.StainlessSteel:
                        selectionStringBuilder.Append("StainlessSteel");                        
                        break;
                    case Material.Titanium:
                        selectionStringBuilder.Append("Titanium");                        
                        break;
                    case Material.Aluminium:
                        selectionStringBuilder.Append("Aluminium");                        
                        break;
                    case Material.Composite:
                        selectionStringBuilder.Append("Composite");                       
                        break;
                    case Material.ReinforcedConcrete:
                        selectionStringBuilder.Append("ReinforcedConcrete");                        
                        break;
                }
                selectionStringBuilder.Append(" ");
            }

            if (crosssections.SelectedItem != null)
            {
                CrossSection selectedCrossSection = (CrossSection)crosssections.SelectedItem;
                switch (selectedCrossSection)
                {
                    case CrossSection.Box:
                        selectionStringBuilder.Append("Box");                       
                        break;
                    case CrossSection.IBeam:
                        selectionStringBuilder.Append("IBeam");                       
                        break;
                    case CrossSection.ZShaped:
                        selectionStringBuilder.Append("ZShaped");                       
                        break;
                    case CrossSection.CShaped:
                        selectionStringBuilder.Append("CShaped");                     
                        break;
                }
                selectionStringBuilder.Append(" ");
            }

            if (testresults.SelectedItem != null)
            {
                TestResult selectedTestResult = (TestResult)testresults.SelectedItem;
                switch (selectedTestResult)
                {
                    case TestResult.Fail:
                        selectionStringBuilder.Append("Fail");
                        break;
                    case TestResult.Pass:
                        selectionStringBuilder.Append("Pass");
                        break;
                }
                selectionStringBuilder.Append(" ");
            }
           label1.Content = selectionStringBuilder.ToString();
        }

        private void RunTests_Click__Click(object sender, RoutedEventArgs e)
        {
            Array results = new Array[10];

            Random rnd = new Random();
            int materialT = rnd.Next(1, 6);      
            Material matTest = (Material)materialT;
            tbTextRes.Text = matTest.ToString();

            Random rnd2 = new Random();
            int testType = rnd2.Next(1, 5);
            CrossSection crossType = (CrossSection)testType;
            tbTextRes.Text = crossType.ToString();

            int passFail = (int)(Convert.ToInt32(matTest)) - (int)(Convert.ToInt32(crossType));
            if(passFail>0)
            {
                tbTextRes.Text = "Pass";
            }
            else
            {
                tbTextRes.Text = "Fail ";
            }          
        }

        private void tbTextRes_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
